package principal;

import entidades.ConjuntoProduto;
import entidades.Fornecedor;
import entidades.Produto;

public class TesteProduto {
	public static void main(String[] args) {

		//Inserts
		Fornecedor forn1 = new Fornecedor("1234321",null, "Zé maria");
		Fornecedor forn2 = new Fornecedor("543212345",null, "Claúdio");
		
		Produto produto1 = new Produto(new Integer(1),"TV LCD", 3500, forn1);
		Produto produto2 = new Produto(new Integer(2),"notebook", 2000, forn2);
		Produto produto3 = new Produto(new Integer(3),"impressora", 232, forn2);
		//atualizarPreco();
		
		
		//Metodos da classe ConjuntoProduto
		ConjuntoProduto conjunto = new ConjuntoProduto();
		conjunto.inserir(produto1);
		conjunto.inserir(produto2);
		conjunto.inserir(produto3);
		conjunto.atualizarPorPorcentagem(10);
		conjunto.mostrarProduto();
	}
}
